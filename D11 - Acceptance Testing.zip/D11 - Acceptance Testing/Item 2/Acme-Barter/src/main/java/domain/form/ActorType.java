package domain.form;

public enum ActorType {
    USER, ADMIN, AUDITOR
}
