package utilities;

import com.mchange.util.AssertException;

public class InvalidPreTestException extends AssertException {

	public InvalidPreTestException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7644059576156748218L;

	
	

}