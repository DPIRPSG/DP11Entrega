package utilities;

import com.mchange.util.AssertException;

public class InvalidPostTestException extends AssertException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7339211636479172598L;

	public InvalidPostTestException(String string) {
		super(string);
	}

	
	

}